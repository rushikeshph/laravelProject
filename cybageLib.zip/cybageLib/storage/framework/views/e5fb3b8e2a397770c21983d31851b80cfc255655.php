 <div class="card mb-3">
    <img src="https://cdn.pixabay.com/photo/2015/05/19/14/55/educational-773651_960_720.jpg" class="card-img-top" alt="...">
    <div class="card-body">
        <h5 class="card-title">List of Books</h5>
        <p class="card-text">You can find here all the informatins about books in the system</p>

 

        <table class="table">
            <thead class="thead-light">
            <tr>
                <th scope="col">Id</th>
                <th scope="col">Book</th>
                <th scope="col">Categort</th>
                <th scope="col">Description</th>
                <th scope="col">Author</th>
                
 

            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $booklists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booklist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($booklist->id); ?></td>
                    <td><?php echo e($booklist->bookName); ?></td>
                    <td><?php echo e($booklist->bookCategory); ?></td>
                    <td><?php echo e($booklist->bookDescription); ?></td>
                    <td><?php echo e($booklist->bookAuthor); ?></td>
                    <td>

 

                        <a href="<?php echo e(url('/edit/'.$booklist->id)); ?>" class="btn btn-sm btn-warning">Edit</a>

 

                    </td>
                    <td>

                    <a href="<?php echo e(url('/delete/'.$booklist->id)); ?>" class="btn btn-sm btn-danger">Delete</a>


                    </td>

 


                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\cybageLib\resources\views/booklists.blade.php ENDPATH**/ ?>