<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Book List</title>

        <!-- Fonts -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

        <!-- Styles -->
      
        </style>
    </head>
    <body>
    @include("navbar");
   <div class="container mr-9 mt-5">
        
    @if($layout == 'index')
    <div class="container-fluid mt-1">
        <div class="container-fluid mt-4">
            <div class="row justify-content-center">
                <section class="col-md-8">
                    @include("booklists")
                </section>
            </div>
        </div>
    </div>
    @elseif($layout == 'create')
    <div class="container-fluid mt-4 " id="create-form">
        <div class="row">
            <section class="col-md-7">
                @include("booklists")
            </section>
            <section class="col-md-5">

 

                <div class="card mb-3">
                    <img src="https://marketplace.canva.com/MAB7yqsko0c/1/screen_2x/canva-smart-little-schoolgirl--MAB7yqsko0c.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Enter the informations of the new Book</h5>
                        <form action="{{ url('/store') }}" method="post">
                            @csrf
                            <div class="form-group">
                                <label>ID</label>
                                <input name="id" type="text" class="form-control"  disabled placeholder="Enter id">
                            </div>
                            <div class="form-group">
                                <label>Book Name</label>
                                <input name="bookName" type="text" class="form-control"  placeholder="Enter the Book Name">
                            </div>



                            <div class="form-group">
                                <label>Category</label>
                                <input name="bookCategory" type="text" class="form-control"  placeholder="Enter Book Category">
                            </div>
                            


                            <div class="form-group">
                                <label>Description</label>
                                <input name="bookDescription" type="text" class="form-control"  placeholder="Enter Description">
                            </div>
                            <div class="form-group">
                                <label>Author</label>
                                <input name="bookAuthor" type="text" class="form-control"  placeholder="Enter Author name">
                            </div>

                            <input type="submit" class="btn btn-info" value="Save">
                            <input type="reset" class="btn btn-warning" value="Reset">

 

                        </form>
                    </div>
                </div>

 

            </section>
        </div>
    </div>
    @elseif($layout == 'edit')
    <div class="container-fluid mt-1">
        <div class="row">
            <section class="col-md-7">
              @include("booklists")
            </section>
            <section class="col-md-5">

 

                <div class="card mb-3">
                    <img src="https://th.bing.com/th/id/R0738d1d55dcc126aef64b74e64eea2b2?rik=Bq4zcH6Iu188cw&riu=http%3a%2f%2fstatic3.depositphotos.com%2f1001378%2f129%2fv%2f950%2fdepositphotos_1292540-Books-and-feather-pen.jpg&ehk=eWIcR75Qrl5DrDcatckmy8lkByqxpmeIOr9Qp9Nl0WM%3d&risl=&pid=ImgRaw" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Update informations of Book</h5>
                        <form action="{{ url('/update/'.$booklist->id) }}" method="post">
                            @csrf
                            <div class="form-group">
                                <label>ID</label>
                                <input value="{{ $booklist->id }}" name="id" type="text" class="form-control"  placeholder="Enter id">
                            </div>
                            <div class="form-group">
                                <label>Book Name</label>
                                <input value="{{ $booklist->bookName }}" name="bookName" type="text" class="form-control"  placeholder="Enter the name">
                            </div>
                            <div class="form-group">
                                <label>Book Category</label>
                                <input value="{{ $booklist->bookCategory }}" name="bookCategory" type="text" class="form-control"  placeholder="Enter category">
                            </div>
                            <div class="form-group">
                                <label>Description</label>
                                <input value="{{ $booklist->bookDescription}}" name="bookDescription" type="text" class="form-control"  placeholder="Enter description">
                            </div>
                            <div class="form-group">
                                <label>Author Name</label>
                                <input value="{{ $booklist->bookAuthor}}" name="bookAuthor" type="text" class="form-control"  placeholder="Enter Author Name">
                            </div>
                            <br>
                            <input type="submit" class="btn btn-info" value="Update">
                            <input type="reset" class="btn btn-warning" value="Reset">

 

                        </form>
                    </div>
                </div>

 

            </section>
        </div>
    </div>
    @endif
 

    
    </body>
</html>
